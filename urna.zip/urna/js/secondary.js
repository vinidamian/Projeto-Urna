var inputFirst = document.getElementById('first');
var inputSecond = document.getElementById('second');
var inputThird = document.getElementById('third');
var inputFourth = document.getElementById('fourth');
var img = document.querySelector('.img-borda img');
var inputNome = document.getElementById('nome');
var inputParido = document.getElementById('partido');
var inputParido1 = document.getElementById('partido1');
var inputTipo = document.getElementById('tipos');
document.getElementById("confirma").disabled = true;

var votos = JSON.parse(localStorage.getItem('list_votos')) || [];

////// LOGIN
function Login() {
    var done = 0;
    var username = document.login.username.value;
    username = username.toLowerCase();
    var password = document.login.password.value;
    password = password.toLowerCase();
    if (username == "1" && password == "1") {
        window.location = "./resultado.html";
        done = 1;
    }
    if (done == 0) {
        alert("Senha ou Usuário inválido.");
    }
}
///// TEMPO
function tempo() {
    setTimeout(function () {
        inputFirst.value = "";
        inputSecond.value = "";
        inputThird.value = "";
        inputFourth.value = "";
        inputNome.value = "";
        inputParido.value = "";
        inputTipo.value = "";
        inputParido1.value = "";
        img.src = '';
        img.src = './img/limpa/branco.png';
        document.getElementById("confirma").disabled = false;
        document.getElementById("branco").disabled = false;
        document.getElementById("corrige").disabled = false;
    }, 1000);
};
/////// BRANCO
function branco() {
    var inputConjunto = "branco";
    inputFirst.value = "";
    inputSecond.value = "";
    inputNome.value = "Voto em Branco";
    inputParido.value = "";
    inputTipo.value = "";
    inputParido1.value = "";
    document.getElementById("confirma").disabled = true;
    document.getElementById("branco").disabled = true;
    document.getElementById("corrige").disabled = true;
    console.log(inputConjunto);
    votos.push(inputConjunto);
    senha();
    salvar();
    tempo();
}
////// LIMPA
function limpa() {
    inputFirst.value = "";
    inputSecond.value = "";
    inputThird.value = "";
    inputFourth.value = "";
    inputNome.value = "";
    inputParido.value = "";
    inputParido1.value = "";
    inputTipo.value = "";
    img.src = './img/limpa/branco.png';
    document.getElementById("confirma").disabled = true;
    document.getElementById("first").focus();
}
//// AUTOTAB
function autotab(original, destination) {
    if (original.getAttribute && original.value.length == original.getAttribute("maxlength")) {
        destination.focus();
        if (original == fourth) {
            document.getElementById("confirma").disabled = false;
            visualizar();
        }
    }
}
/////// SENHA
function senha() {
    setTimeout(function () {
        var senha = 321;
        var pedir = parseInt(prompt("De a senha:"));
        if (pedir == senha) {
            window.location = './index.html';
        } else {
            while (pedir != senha) {
                pedir = parseInt(prompt("De a senha:"));
            }
        }
    }, 1001);
};
//////// JSON
function salvar() {

    localStorage.setItem('list_votos', JSON.stringify(votos));
}
////// CONFIRMA
function confirma() {

    document.getElementById("confirma").disabled = true;
    document.getElementById("branco").disabled = true;
    document.getElementById("corrige").disabled = true;

    var first = inputFirst.value;
    var second = inputSecond.value;
    var third = inputThird.value;
    var fourth = inputFourth.value;
    var inputConjunto = (first + second + third + fourth);

    if (inputConjunto == '0000') {
        inputConjunto = 'nulo'
        votos.push(inputConjunto);
    } else {
        votos.push(inputConjunto);
    }

    salvar();
    tempo();
    senha();
}

//////////// VISUALIZAR
function visualizar() {
    var first = inputFirst.value;
    var second = inputSecond.value;
    var third = inputThird.value;
    var fourth = inputFourth.value;
    var inputConjunto = (first + second + third + fourth);
    switch (inputConjunto) {

        /////// 2B

        case '6748':
            img.src = './img/MAD/caioE.jpeg';
            inputNome.value = 'Caio Eduardo de Espindola';
            inputParido.value = 'MAD - Movimento Amplo de Direita';
            inputTipo.value = 'Deputado';
            break;

        case '6778':
            img.src = './img/MAD/vitorC.jpeg';
            inputNome.value = 'Vitor Lostada da Cunha';
            inputParido.value = 'MAD - Movimento Amplo de Direita';
            inputTipo.value = 'Deputado';
            break;

        case '6726':
            img.src = './img/MAD/samuel.jpeg';
            inputNome.value = 'Samuel de Sousa Araujo Silva';
            inputParido.value = 'MAD - Movimento Amplo de Direita';
            inputTipo.value = 'Deputado';
            break;

        case '4227':
            img.src = './img/PLB/luiz.jpeg';
            inputNome.value = 'Luiz Gustavo da Silva Penachin';
            inputParido.value = 'PLB - Partido Liberal Brasileiro';
            inputTipo.value = 'Deputado';
            break;

        case '4242':
            img.src = './img/PLB/pedro.jpeg';
            inputNome.value = 'Pedro Valentin Dutra';
            inputParido.value = 'PLB - Partido Liberal Brasileiro';
            inputTipo.value = 'Deputado';
            break;

        case '4201':
            img.src = './img/PLB/joaoB.jpeg';
            inputNome.value = 'João Vitor Schwambach Brasil';
            inputParido.value = 'PLB - Partido Liberal Brasileiro';
            inputTipo.value = 'Deputado';
            break;

        case '6969':
            img.src = './img/PBM/gabrielZ.jpeg';
            inputNome.value = 'Gabriel Zatorski';
            inputParido.value = 'PBM - Partido Brasil Melhor';
            inputTipo.value = 'Deputado';
            break;

        case '6996':
            img.src = './img/PBM/joaoP.jpeg';
            inputNome.value = 'João Pedro Philippi Ferreira';
            inputParido.value = 'PBM - Partido Brasil Melhor';
            inputTipo.value = 'Deputado';
            break;

        case '6966':
            img.src = './img/PBM/arthur.jpeg';
            inputNome.value = 'Arthur George da Silva';
            inputParido.value = 'PBM - Partido Brasil Melhor';
            inputTipo.value = 'Deputado';
            break;

        case '2403':
            img.src = './img/PJ/giulia.jpeg';
            inputNome.value = 'Giulia Sbors Pereira';
            inputParido.value = 'PJ - Partido Justo';
            inputTipo.value = 'Deputado';
            break;

        case '2420':
            img.src = './img/PJ/lucasB.jpeg';
            inputNome.value = 'Lucas Belli da Silva';
            inputParido.value = 'PJ - Partido Justo';
            inputTipo.value = 'Deputado';
            break;

        case '2442':
            img.src = './img/PJ/sophia.jpeg';
            inputNome.value = 'Sophia Graccioli Marçal Salvan';
            inputParido.value = 'PJ - Partido Justo';
            inputTipo.value = 'Deputado';
            break;

        case '3911':
            img.src = './img/PLCJ/gabrielS.jpeg';
            inputNome.value = 'Gabriel de Souza';
            inputParido.value = 'PLCJ - Partido Liberal das Causas Justas';
            inputTipo.value = 'Deputado';
            break;

        case '3995':
            img.src = './img/PLCJ/kaue.jpeg';
            inputNome.value = 'Kauê Luiz de Borba';
            inputParido.value = 'PLCJ - Partido Liberal das Causas Justas';
            inputTipo.value = 'Deputado';
            break;

        case '3947':
            img.src = './img/PLCJ/theo.jpeg';
            inputNome.value = 'Théo Andrade Thiesen';
            inputParido.value = 'PLCJ - Partido Liberal das Causas Justas';
            inputTipo.value = 'Deputado';
            break;

        case '9898':
            img.src = './img/PDM/ana.jpeg';
            inputNome.value = 'Ana Elisa Rieg Dias';
            inputParido.value = 'PDM - Partido das Mulheres';
            inputTipo.value = 'Deputado';
            break;

        case '9828':
            img.src = './img/PDM/gabrielaO.jpeg';
            inputNome.value = 'Gabriela Oliveira da Silva';
            inputParido.value = 'PDM - Partido das Mulheres';
            inputTipo.value = 'Deputado';
            break;

        case '9858':
            img.src = './img/PDM/natalia.jpeg';
            inputNome.value = 'Natalia Maria Luz';
            inputParido.value = 'PDM - Partido das Mulheres';
            inputTipo.value = 'Deputado';
            break;

        case '2602':
            img.src = './img/MMCB/beatriz.jpeg';
            inputNome.value = 'Beatriz Inacio Martins';
            inputParido.value = 'MMCB';
            inputTipo.value = 'Deputado';
            break;

        case '2603':
            img.src = './img/MMCB/carol.jpeg';
            inputNome.value = 'Carolina Ribeiro Nuernberg';
            inputParido.value = 'MMCB - Movimento Moderno da Causa';
            inputParido1.value = 'Brasileira';
            inputTipo.value = 'Deputado';
            break;

        case '2604':
            img.src = './img/MMCB/maria.jpeg';
            inputNome.value = 'Maria Eduarda Longo';
            inputParido.value = 'MMCB - Movimento Moderno da Causa';
            inputParido1.value = 'Brasileira';
            inputTipo.value = 'Deputado';
            break;

        case '8707':
            img.src = './img/PCLdB/yan.jpg';
            inputNome.value = 'Yan Carlos Souza Moraes';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            inputTipo.value = 'Deputado';
            break;

        case '8776':
            img.src = './img/PCLdB/nicolas.jpg';
            inputNome.value = 'Nycolas Padilha Pinheiro';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            inputTipo.value = 'Deputado';
            break;

        case '8712':
            img.src = './img/PCLdB/robson.jpg';
            inputNome.value = 'Robson Vitor Silva da Silva';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            inputTipo.value = 'Deputado';
            break;

        ///////// 2A


        case '3714':
            img.src = './img/PSDD/nathalia.jpg';
            inputNome.value = 'Nathalia Accordi';
            inputParido.value = 'PSDD - Partido Social Democrata da';
            inputParido1.value = 'Diversidade';
            inputTipo.value = 'Deputado';
            break;

        case '3713':
            img.src = './img/PSDD/antonio.jpg';
            inputNome.value = 'Antonio Schuch';
            inputParido.value = 'PSDD - Partido Social Democrata da';
            inputParido1.value = 'Diversidade';
            inputTipo.value = 'Deputado';
            break;

        case '3731':
            img.src = './img/PSDD/juliaC.jpg';
            inputNome.value = 'Julia Chaltein';
            inputParido.value = 'PSDD - Partido Social Democrata da';
            inputParido1.value = 'Diversidade';
            inputTipo.value = 'Deputado';
            break;

        case '6660':
            img.src = './img/PCA/arthurD.jpg';
            inputNome.value = 'Arthur Farias';
            inputParido.value = 'PCA - Partido Cripto Anarquista';
            inputTipo.value = 'Deputado';
            break;

        case '6669':
            img.src = './img/PCA/lucasN.jpg';
            inputNome.value = 'Lucas Nazário';
            inputParido.value = 'PCA - Partido Cripto Anarquista';
            inputTipo.value = 'Deputado';
            break;

        case '6699':
            img.src = './img/PCA/thomas.jpg';
            inputNome.value = 'Thomas Niehues';
            inputParido.value = 'PCA - Partido Cripto Anarquista'
            inputTipo.value = 'Deputado';
            break;

        case '4925':
            img.src = './img/PRD/marcus.jpg';
            inputNome.value = 'Marcus Vinicius';
            inputParido.value = 'PRD - Partido da Renovação Democrática';
            inputTipo.value = 'Deputado';
            break;

        case '4911':
            img.src = './img/PRD/juliaT.jpg';
            inputNome.value = 'Julia Trento';
            inputParido.value = 'PRD - Partido da Renovação Democrática';
            inputTipo.value = 'Deputado';
            break;

        case '4913':
            img.src = './img/PRD/barbara.jpg';
            inputNome.value = 'Barbara Monique';
            inputParido.value = 'PRD - Partido da Renovação Democrática';
            inputTipo.value = 'Deputado';
            break;

        case '5705':
            img.src = './img/PDL/luana.jpg';
            inputNome.value = 'Luana Paimel';
            inputParido.value = 'PDL - Partido Democrático Liberal';
            inputTipo.value = 'Deputado';
            break;

        case '5769':
            img.src = './img/PDL/matheusP.jpg';
            inputNome.value = 'Matheus Paraiso';
            inputParido.value = 'PDL - Partido Democrático Liberal';
            inputTipo.value = 'Deputado';
            break;

        case '5701':
            img.src = './img/PDL/andre.jpg';
            inputNome.value = 'André Luiz de Oliveira Conrado';
            inputParido.value = 'PDL - Partido Democrático Liberal';
            inputTipo.value = 'Deputado';
            break;

        case '9766':
            img.src = './img/FNB/marcosH.jpg';
            inputNome.value = 'Marcos Henrique Warmling';
            inputParido.value = 'FNB - Frente Neo Liberal Brasileira';
            inputTipo.value = 'Deputado';
            break;


        case '9723':
            img.src = './img/FNB/lucasM.jpg';
            inputNome.value = 'Lucas Medeiros Marcos';
            inputParido.value = 'FNB - Frente Neo Liberal Brasileira';
            inputTipo.value = 'Deputado';
            break;

        case '9788':
            img.src = './img/FNB/miguel.jpg';
            inputNome.value = 'Miguel Gonzaga Machado';
            inputParido.value = 'FNB - Frente Neo Liberal Brasileira';
            inputTipo.value = 'Deputado';
            break;

        case '0666':
            img.src = './img/PLIE/gabriel.jpg';
            inputNome.value = 'Gabriel Vagner';
            inputParido.value = 'PLIE - Partido da Liberdade Individual';
            inputParido1.value = "e Econômica";
            inputTipo.value = 'Deputado';
            break;

        case '0699':
            img.src = './img/PLIE/mateusN.jpg';
            inputNome.value = 'Matheus de Carlini Neves';
            inputParido.value = 'PLIE - Partido da Liberdade Individual';
            inputParido1.value = "e Econômica";
            inputTipo.value = 'Deputado';
            break;

        case '0677':
            img.src = './img/PLIE/reinaldo.jpg';
            inputNome.value = 'Reinaldo Aparecido Ramos';
            inputParido.value = 'PLIE - Partido da Liberdade Individual';
            inputParido1.value = "e Econômica";
            inputTipo.value = 'Deputado';
            break;

        case '8803':
            img.src = './img/PRL/gabrielaG.jpg';
            inputNome.value = 'Gabriela Gamba';
            inputParido.value = 'PRL - Partido do Respeito e Liberdade';
            inputTipo.value = 'Deputado';
            break;

        case '8802':
            img.src = './img/PRL/isabela.jpg';
            inputNome.value = 'Isabela Lopes da Silva';
            inputParido.value = 'PRL - Partido do Respeito e Liberdade';
            inputTipo.value = 'Deputado';
            break;

        case '8801':
            img.src = './img/PRL/victorN.jpg';
            inputNome.value = 'Victor Nascimento';
            inputParido.value = 'PRL - Partido do Respeito e Liberdade';
            inputTipo.value = 'Deputado';
            break;

        case '0000':
            inputNome.value = "Voto Nulo";
            inputParido.value = "";
            inputParido1.value = "";
            inputTipo.value = "";
            break;

        default:
            img.src = './img/limpa/branco.png';
            inputNome.value = 'Candidato inexistente';
            inputParido.value = "";
            inputParido1.value = "";
            inputTipo.value = "";
            document.getElementById("confirma").disabled = true;
            break;
    }
}